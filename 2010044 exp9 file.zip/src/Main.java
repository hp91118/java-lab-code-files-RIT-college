import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;
// file reading using File class and scanner
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");

        File f = new File("C:\\Users\\aquar\\OneDrive\\Desktop\\demofile3.txt");
        System.out.println(f.getName());
        System.out.println(f.getAbsoluteFile());
        System.out.println(f.length());
        try {
            Scanner sc=new Scanner(f);
            while (sc.hasNextLine()){
                String data=sc.nextLine();
                System.out.println(data);
            }
            sc.close();
            System.out.println(f.length());
        }
        catch (Exception e){
            System.out.println("Error");
        }
    }

}
/*
Hello world!
demofile3.txt
C:\Users\aquar\OneDrive\Desktop\demofile3.txt
6
ab
cd
6
 */