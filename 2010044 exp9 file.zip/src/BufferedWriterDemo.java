import java.io.*;

public class BufferedWriterDemo {
    public static void main(String args[]) throws IOException {
       /* FileWriter fw=new FileWriter("demofile2.txt",true);
        BufferedWriter bw=new BufferedWriter(fw);
        bw.write("This is demofile2.txt we are using BufferedWriter class");
        bw.newLine();//to add new line
        bw.write("write() method");
        bw.write("123");
        bw.newLine();
        String s="this is string ";
        bw.write(s,3,9);//starts with 0
        char arr[]={'a','b','c','d'};//starts with 0
        bw.newLine();
       bw.write(arr,2,2);
        bw.append("\nhello");
        bw.close();
        */
        //BufferedReader demo
        FileReader fr=new FileReader("demofile2.txt");
        BufferedReader br=new BufferedReader(fr);
       int i=br.read();
        while (i!=-1){
            System.out.print((char)i);
            i=br.read();
        }


        //readline to read text lin eby line
        String str;
        while((str=br.readLine()) != null){
            System.out.println(str);
        }
        br.close();
        fr.close();
    }
}
/*
This is demofile2.txt we are using BufferedWriter class
write() method123
s is stri
cd
hello
 */