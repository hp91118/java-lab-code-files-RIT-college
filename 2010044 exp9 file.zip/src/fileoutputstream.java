/*
String content cannot be directly written into
	  a file. It needs to be converted into bytes
 */

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class fileoutputstream {
    public static void main(String args[]) throws IOException {
        FileOutputStream fos=new FileOutputStream("demofile3.txt",true);
        File f=new File("demofile3.txt");
        fos.write(65);
        String s="Welcome";
        byte b[]=s.getBytes();
        fos.write(b);
        System.out.println("Size of file :"+f.length());//Size of file :8
        fos.close();;

    }
}
