/*
createNewFile()  This method returns a
 boolean value: true if the file was successfully created,
  and false if the file already exists.
 */
import java.io.File;
import java.io.IOException;

public class File1 {
    public static void main(String args[]){
        try {
            File file1=new File("demofile4.txt");
            if(file1.createNewFile()){
                System.out.println("Done");
            }
            else {
                System.out.println("File exists");
            }
        }
        catch (IOException i){
            System.out.println("Error");
            i.printStackTrace();
        }



    }



}
/*
Done
 */