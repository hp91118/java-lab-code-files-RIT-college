import java.io.FileWriter;
import java.io.File;
import java.io.IOException;
//file wriring using FileWriter

public class File2 {
    public static void main(String args[]){

        try {
          //  File file = new File("C:\\Users\\aquar\\OneDrive\\Desktop\\demofile3.txt");
            FileWriter fw = new FileWriter("C:\\Users\\aquar\\OneDrive\\Desktop\\demofile3.txt");
                fw.write("Hello world !!!! welcome everyone");
                fw.close();
                System.out.println("Writing done .....");
        }
        catch (IOException e){
            e.printStackTrace();
        }
        System.out.println();
    }

}
/*
created :C:\Users\aquar\IdeaProjects\project9\demofile3.txt
Name :demofile3.txt
Hello world !!!!hello hey everyone
 */