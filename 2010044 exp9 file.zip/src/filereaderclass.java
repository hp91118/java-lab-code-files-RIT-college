import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
//FileReader fr.read returns -1 at eof

public class filereaderclass {
    public static void main(String args[]) throws IOException {
        File f=new File("C:\\Users\\aquar\\OneDrive\\Desktop\\demofile4.txt");
        FileWriter fw=new FileWriter("C:\\Users\\aquar\\OneDrive\\Desktop\\demofile4.txt",true);
        fw.write("line1");
        System.out.println("File size :"+f.length());
        fw.append("line2");
        fw.append("line3");
        fw.close();
        System.out.println("File size :"+f.length());//here only we get 15


        FileReader fr=new FileReader("C:\\Users\\aquar\\OneDrive\\Desktop\\demofile4.txt");
        int i=fr.read();
        while (i!=-1){
            System.out.print((char)i);
            i=fr.read();
        }

        System.out.println("File size :"+f.length());
        fr.close();
        System.out.println("File size :"+f.length());


    }
}

/*
File size :15
line1line2line3File size :15
 */
