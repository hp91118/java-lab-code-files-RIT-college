import java.io.FileWriter;
import java.io.IOException;

public class FileWriterDemo {
    public static void main(String args[])throws IOException {
        FileWriter fw=new FileWriter("demofile5.txt");
        String s="Gayatri is good girl\n hello";
        int l=0;
        while(l<s.length()){
            fw.write(s.charAt(l));
            l++;
        }
        fw.close();
        System.out.println("Done");
    }
}
/*
Gayatri is good girl
 hello
 */
