import java.io.FileInputStream;
import java.io.IOException;
/*

The ASCII value of the lowercase alphabet is from 97 to 122.
 uppercase alphabet is from 65 to 90.
  for reading binary data.

 */

public class fileinputstream {
    public static void main(String args[]) throws IOException{
        System.out.println("Reading file using FileInputStream ");
        FileInputStream fis=new FileInputStream("demofile3.txt");
        int i=fis.read();
        while (i!=-1) {
            System.out.print(i );
            System.out.print((char) i+"\t");
            i = fis.read();
        }
        fis.close();
    }
}

/*
hello is file content
Reading file using FileInputStream
104h	101e	108l	108l	111o
 */