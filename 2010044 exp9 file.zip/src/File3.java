import java.io.File;
import java.io.IOException;

public class File3 {
    public static void main(String arg[]) throws IOException {
        File f=new File("demofile3.txt");
        System.out.println("f.creteNewFile "+f.createNewFile());
        System.out.println("f.exists "+f.exists());
        System.out.println("f.length "+f.length());
        System.out.println("f.getAbsolutePath "+f.getAbsoluteFile());
        System.out.println("f.getName "+f.getName());
        System.out.println("f.isFile "+f.isFile());
        System.out.println("f.canRead "+f.canRead());
        System.out.println("f.canWrite "+f.canWrite());
    }
}
/*
f.creteNewFile false
f.exists true
f.length 5
f.getAbsolutePath C:\Users\aquar\IdeaProjects\project9\demofile3.txt
f.getName demofile3.txt
f.isFile true
f.canRead true
f.canWrite true
file content is hello
 */