
import java.util.Scanner;
public class Max_3 {
    public static void main(String args[]) {
        int num1, num2,num3;
        System.out.println("Enter num1,num2,num3 ");
        Scanner sc = new Scanner(System.in);
        num1 = sc.nextInt();
        num2 = sc.nextInt();
        num3=sc.nextInt();
        if(num1>num2 && num1>num3){
            System.out.println("Max number "+num1);
        }
        else if (num2>num3){
            System.out.println("Max number "+num2);

        }
        else{
            System.out.println("Max number "+num3);
        }
    }}
/*
Enter num1,num2,num3
20
200
400
Max number 400

 */
