
import java.util.Scanner;
public class Palindrome{
    public static void main(String args[]) {
        int n,d,sum=0,temp;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number :");
        n = sc.nextInt();
        temp=n;
        while(n>0){
            d=n%10;
            sum=(sum*10)+d;
            n=n/10;
        }
        if(temp==sum){
            System.out.println( temp+" is palindrome ");
        }
        else{
            System.out.println(temp+" is not palindrome ");
        }
    }}
/*
Enter number :
151
151 is palindrome

Enter number :
122
122 is not palindrome


 */