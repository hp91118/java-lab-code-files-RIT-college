

//Factorial using command line argument
class factorial_cmd {
    public static void main(String args[]){
        int i,fact=1,n;
        n=Integer.parseInt(args[0]);
        for(i=1;i<=n;i++){
            fact=fact*i;
        }
        System.out.println(" factorial :"+fact);
    }
}
/*
output
Windows PowerShell
Copyright (C) Microsoft Corporation. All rights reserved.

Try the new cross-platform PowerShell https://aka.ms/pscore6

PS C:\Users\aquar\IdeaProjects\project2> cd src
PS C:\Users\aquar\IdeaProjects\project2\src> java factorial_cmd.java 6
 factorial :720
 */

