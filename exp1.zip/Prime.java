import java.util.Scanner;
public class Prime{
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number :");
        int num1 = sc.nextInt();
        for(int i=2;i<num1;i++){
        if(num1%i==0){
            System.out.println(num1+" is not prime ");
            break;
        }
        else {
            System.out.println(num1+" is prime");
            break;
        }
        }
    }}
/*output
Enter number :
11
11 is prime

 */
