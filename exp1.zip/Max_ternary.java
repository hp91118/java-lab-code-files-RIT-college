import java.util.Scanner;
public class Max_ternary {
    public static void main(String args[]) {
        int num1, num2;
        System.out.println("Enter num1 and num2 ");
        Scanner sc=new Scanner(System.in);
        num1=sc.nextInt();
        num2=sc.nextInt();

        int result = num1 > num2 ? num1 : num2;
        System.out.println("Max number :" + result);

    }
}
/*
Enter num1 and num2
12
13
Max number :13

 */