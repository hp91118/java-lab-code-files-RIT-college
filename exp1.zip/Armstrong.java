import java.lang.Math;
import java.util.Scanner;
public class Armstrong{
    public static void main(String args[]) {
        int n,d,c=0,t,sum=0,temp,r;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number :");
        n = sc.nextInt();
        t=n;
        temp=n;
        while(t>0){
            r=t%10;//remember
            c++;
            t=t/10;
        }
        //System.out.println(t);
        System.out.println(c+"Digits");
        while(n>0){
            d=n%10;
            sum=sum+(int)Math.pow(d,c);
            n=n/10;
        }
        if(temp==sum){
            System.out.println( temp+" is Armstrong ");
        }
        else{
            System.out.println(temp+" is not Armstrong");
        }
    }}
/*op
Enter number :
1634
4Digits
1634 is Armstrong

 */