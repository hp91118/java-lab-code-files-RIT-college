import java.util.Scanner;
public class Biodata {
    public static void main(String args[]) {
        String name = "Gayatri Gomewadikar";
        int age = 20;
        String bod = "09/12/2002";
        String email = "gayu@gmail.com";
        String course = "B.Tech";
        System.out.println("Biodata\n"  + name + "\n" + age + "\n" + bod + "\n" + email + "\n" + course);
        Scanner sc = new Scanner(System.in);
        // For string as user input
        System.out.println("Enter City :");
        String str = sc.nextLine();
        System.out.println("From " + str);
    }
}
/*op
Biodata
Gayatri Gomewadikar
20
09/12/2002
gayu@gmail.com
B.Tech
Enter City :
sangli
From sangli
Process finished with exit code 0


 */