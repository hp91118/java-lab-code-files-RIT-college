import java.util.Scanner;
public class Strong {
     public int cal(int n){
        int i,fact=1;
        for (i=1;i<=n;i++){
            fact=fact*i;
        }
        return fact;
    }
    public static void main(String args[]){
         int d,val,sum=0,no,temp;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter number :");
        no=sc.nextInt();
        temp=no;
        Strong obj1=new Strong();
        while(no>0){
            d=no%10;
             val=obj1.cal(d);
             no=no/10;
             sum=sum+val;

        }
        System.out.println(sum);
        if(temp==sum){
            System.out.println( temp+" is strong ");
        }
        else{
            System.out.println(temp+" is not strong");
        }

    }
}
/*op
Enter number :
145
145
145 is strong
logic fact=1,sum=0
while(n>0){
d=n%10
for(i=1;i<=n;i++){
    f=fact*i}

 n=n/10
 sum=sum+f}
 */
