
//calculator using operator
import java.util.Scanner;
class calculator{
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter an operator (+, -, *, /): ");
        char op = sc.next().charAt(0);
        System.out.println("Enter num1 :");
        double num1=sc.nextDouble();
        System.out.println("Enter num2 :");
        double num2=sc.nextDouble();
        double res;
// Ways to print output in Switch
        switch(op){
            case '+':
                System.out.println("add "+ Double.toString(num1+num2));//+ string is printed
                break;
            case '-'://'' is required not ""
                double sub;
                sub=num1+num2;
                System.out.println("Subtraction"+ sub);
                break;
            case'*':
                res=num1*num2;
                System.out.println("Multiplication :"+res);
                break;
            case'/':
                res=num1/num2;
                System.out.println("Division :"+res);
                break;
            default:
                System.out.println("Enter valid choice");

        }

    }
}

/*op
Enter an operator (+, -, *, /): *
Enter num1 :
10
Enter num2 :
400
Multiplication :4000.0

Process finished with exit code 0



/*

//calculator recurring if as per user choice
 import java.util.Scanner;
public class calculator{
    public static void main(String args[]){
        int num1,num2,ch;
        System.out.println("1.add 2.sub 3.mul 4.div 5.exit ");
        while(true){
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter choice ");
            ch=sc.nextInt();
            if (ch==5){
                System.out.println("Terminating.......");
                System.exit(0);
            }
            System.out.println("Enter number 1");
            num1=sc.nextInt();
            System.out.println("Enter number 2");
            num2=sc.nextInt();

 switch(ch){
                case 1:
                    int c=num1+num2;
                    System.out.println("Sum "+c);
                    break;
                case 2:
                    int d=num1-num2;
                    System.out.println("Sub "+d);
                    break;
                case 3:
                    int e=num1*num2;
                    System.out.println("mul "+e);
                    break;
                case 4:
                    int f=num1/num2;
                    System.out.println("div "+f);
                    break;
                default:
                    System.out.println("Enter valid option ");


            }

        }

    }
}
 */
/*output
1.add 2.sub 3.mul 4.div 5.exit
Enter choice
2
Enter number 1
10
Enter number 2
3
Sub 7
Enter choice
5
Terminating.......

 */




