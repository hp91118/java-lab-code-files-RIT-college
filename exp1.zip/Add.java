import java.util.Scanner;
public class Add {
    public static void main(String args[]) {
        int num1, num2, sum;
        System.out.println("Enter num1 :");
        Scanner sc = new Scanner(System.in);
        num1 =sc.nextInt();
        System.out.println("Enter num2 :");
        num2 =sc.nextInt();
        sum=num1+num2;
        System.out.println("Sum of "+num1+" and "+num2 +" is "+sum);

    }

}
/*op
Enter num1 :
12
Enter num2 :
9
Sum of 12 and 9 is 21

Process finished with exit code 0


 */
