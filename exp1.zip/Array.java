import java.util.Scanner;
public class Array {
    public static void main(String args[]){
        int size,sum=0;
        System.out.println("Enter Size of 1D array :");
        Scanner sc=new Scanner(System.in);
        size=sc.nextInt();
        int [] array=new int[size];
        System.out.println("Enter elements of 1D array :");
        for(int i=0;i<size;i++){
            array[i]=sc.nextInt();
        }
        for(int i=0;i<size;i++){
            sum=sum+array[i];
        }
        System.out.println("Sum of array elements :"+sum);

    }
}
/*
Enter Size of 1D array :
10
Enter elements of 1D array :
1
2
3
4
5
6
7
8
9
10
Sum of array elements :55

 */