/*
Checked Exception
The classes that directly inherit the Throwable class
except RuntimeException and Error are known as checked exceptions.
 For example, IOException, SQLException, etc. Checked exceptions
 are checked
at compile-time.
A caller is a function that calls another function; a callee is a function that was called. T
 */
class Throwskw
{
    public static void main(String args[]) throws InterruptedException
    {
        Thread.sleep(10000);
        System.out.println("Hello");
        System.out.println("End of the code");
    }
}
/*
Hello
End of the code

 */
//prg2
