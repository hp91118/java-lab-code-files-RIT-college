public class NullPointer {
    public static void main(String args[]) {
        String name = null;
        try {

            System.out.println(name.toLowerCase());
        }
        catch (Exception e){
            System.out.println("String is Null");
        }
    }
}
