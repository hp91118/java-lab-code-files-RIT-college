public class OutofMemory {
    public static void main(String args[]) {
        try {
            int[] a = new int[1000000000];
            System.out.println("Hello");
        }
        catch (OutOfMemoryError e){
            System.out.println(e);
        }
    }
}
/*
java.lang.OutOfMemoryError: Java heap space

 */