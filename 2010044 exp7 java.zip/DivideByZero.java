public class DivideByZero {
    public static void main(String args[]){
        try{
            int a=100/0;
        }
        catch (ArithmeticException e){
            System.out.println("can't divide by zero");
        }
        finally {
            System.out.println("in finaly block");
        }
        /*
        can't divide by zero
        in finaly block
         */
    }
}
