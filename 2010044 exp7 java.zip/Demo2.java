import packagearea.Class2;
public class Demo2{
public static void main(String arg[]){

Class2 obj=new Class2();
obj.circlearea(2);
obj.trianglearea(10,2);
obj.rectanglearea(10,10);
obj.squarearea(10);
}
}
/*


C:\Users\aquar\OneDrive\Desktop\javapkg>javac -d . Class2.java

C:\Users\aquar\OneDrive\Desktop\javapkg>javac Demo2.java

C:\Users\aquar\OneDrive\Desktop\javapkg>java Demo2
Area of circle :12.568
Area of triangle :10.0
Area of rectangle :100.0
Area of triangle :100.0

C:\Users\aquar\OneDrive\Desktop\javapkg>

*/