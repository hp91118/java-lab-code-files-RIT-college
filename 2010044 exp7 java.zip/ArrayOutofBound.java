public class ArrayOutofBound {
    public static void main(String args[]) {
        int arr[] = new int[5];
        String str="gayatri";
        try {
            arr[5] = 3;
            System.out.println(arr[2]);
        }

        catch (ArrayIndexOutOfBoundsException a){
            System.out.println("exception occured "+a);
        }
        try {
            char c=str.charAt(12);
        }
        catch (StringIndexOutOfBoundsException s){
            System.out.println(s);
        }
    }
}

/*

exception occured java.lang.ArrayIndexOutOfBoundsException: Index 5 out of bounds for length 5
java.lang.StringIndexOutOfBoundsException: Index 12 out of bounds for length 7
1.  we can see that the catch block didn't contain the exception code. So, enclose exception code within a try block and use catch block only to handle the exceptions.

 */
