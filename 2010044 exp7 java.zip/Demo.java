import mypackage.Class1;
import java.util.Scanner;
public class Demo{
public static void main(String args[]){
System.out.println("Welcome to calcuator.........");
Class1 obj1=new Class1();
Scanner sc=new Scanner(System.in);

while(true){
System.out.println("Enter choice 1.add 2.sub 3.div 4.mul :");
int ch=sc.nextInt();
if(ch==5){System.out.println("Taking Exit......");
System.exit(0);}
System.out.println("Enter numbers for calculation :-");
int num1=sc.nextInt();
int num2=sc.nextInt();
switch(ch){
case 1:
obj1.add(num1,num2);
break;
case 2:
obj1.sub(num1,num2);
break;
case 3:
obj1.div(num1,num2);
break;
case 4:
obj1.mul(num1,num2);
break;
default:
System.out.println("Something went Wrong .....");
}//switch
} 

}
}