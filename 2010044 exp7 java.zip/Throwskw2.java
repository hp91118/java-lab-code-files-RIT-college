/*
class Throwskw2{

    static void display(int a,int b)throws Exception{
        int r=a/b;
    }
    public static void main(String args[]){
        //main calls the display method so handles
        try{
            display(10,0);
        }
        catch(Exception e){
            System.out.println("Divide by Zero");
        }
    }
}
 */
//throws keyword is to surprass the exception and not to handle
//throws is indication to caller to handle that exception according him

class Throwskw2{
    static void check(int age) throws ArithmeticException{
       if(age<18){
           throw new ArithmeticException("Access Denied");
       }
       else{
           System.out.println("Access granted");
       }
    }
    public static void main(String args[]){
        try {
            check(12);
        }
        catch (Exception e)
        {
            System.out.println("Age exception handled in catch block ");
        }
    }
}


