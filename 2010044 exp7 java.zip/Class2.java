package packagearea;
public class Class2{
public void circlearea(float r){
System.out.println("Area of circle :"+(3.142*r*r));
}
public void trianglearea(float b, float h){
System.out.println("Area of triangle :"+(0.5*b*h));
}
public void rectanglearea(float l, float b){
System.out.println("Area of rectangle :"+(l*b));
}
public void squarearea(float s){
System.out.println("Area of triangle :"+(s*s));
}



}