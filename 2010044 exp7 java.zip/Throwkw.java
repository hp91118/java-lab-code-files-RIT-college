import java.util.Scanner;
/*
public class Throwkw {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your age :");
        int age=sc.nextInt();
        if(age<18){
            throw new ArithmeticException("You are not adult ");
        }
        else{
            throw new ArithmeticException("You are adult ");
        }
        // The finally block follows the try-catch block.
    }
}

 */
public class Throwkw {
    static void canVote(int age){
        if(age<18)
            try{
                throw new Exception();
            }
        catch(Exception e){
                System.out.println("you are not an adult!");
            }
        else
            System.out.println("you can vote!");
    }
    public static void main (String[] args) {
        canVote(20);
        canVote(10);
    }
}
/*
you can vote!
you are not an adult!

 */
    /*
 Refer mygreatlearning

     */
