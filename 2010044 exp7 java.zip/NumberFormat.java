public class NumberFormat {
public static void main(String args[]){
    String s1="Gayatri";
    try {
        int num3=Integer.parseInt("123");
        System.out.println(num3);

        int num1=Integer.parseInt(s1);
        System.out.println("hello");//not printed
    }
    catch (Exception e){
        System.out.println("Number format ex");
    }
    //try followed by catch
    try{
        int num2=Integer.parseInt("null");
    }
    catch(NumberFormatException n){
        System.out.println("string is null");
    }

}
}
/*
123
Number format ex
string is null
refer gfg
 */
