/*	Write a program to print the area of
a rectangle by creating a class
named 'Area' having two methods.
First method named as 'setDim'
takes length and breadth of rectangle as
parameters and the second method named as
'getArea' returns the area of the rectangle.
Length and breadth
of rectangle are entered through
keyboard
 */
import java.util.Scanner;
class Area_1 {
    float len, bre,area_rec;
    void set_dim() {
        System.out.println("Enter length and breadth of rectangle :");
        Scanner sc=new Scanner(System.in);
        len=sc.nextFloat();
        bre=sc.nextFloat();
    }
    void getArea(){
             area_rec=len*bre;
            System.out.println("Area= "+area_rec);
        }
    }

public class Area{
    public static void main(String args[]){
        Area_1 obj=new Area_1();
        obj.set_dim();
        obj.getArea();
    }
}
/*
Enter length and breadth of rectangle :
12
12
Area= 144.0
 */
