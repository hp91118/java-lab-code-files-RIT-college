/*
7)	Write a program by creating an 'Employee' class having the following methods and print the final salary.
i) - 'getInfo()' which takes the salary, number of hours of work per day of employee as parameter
ii) - 'AddSal()' which adds $10 to salary of the employee if it is less than $500.
ii) - 'AddWork()' which adds $5 to salary of employee if the number of hours of work per day is more than 6 hours.

 */
import java .util.Scanner;
 class employee {
    double sal;
    int hr;

    void get_info(){
        System.out.println("Enter Salary :");
        Scanner sc=new Scanner(System.in);
        sal=sc.nextDouble();
        System.out.println("Enter hours per day :");
        hr=sc.nextInt();
    }
    void add_sal(){
        if(sal<500){
            sal=sal+10;
        }
    }
    void add_work(){
        if(hr>6){
            sal=sal+5;
        }
    }
}
public class emp2{
     public static void main(String args[]){
      employee obj1=new employee();
      obj1.get_info();
      obj1.add_sal();
      obj1.add_work();
      System.out.println("Salary :"+obj1.sal);
     }
}
/*
Enter Salary :
2500
Enter hours per day :
8
Salary :2505.0

 */
