/*

6)	Write a program that would print the information (name, year of joining, salary, address)
of three employees by creating a class named 'Employee'. The output should be as follows:
Name        Year of joining        Address
Robert            1994                64C- WallsStreat
Sam                2000                68D- WallsStreat
John                1999                26B- WallsStreat

 */
class Employee1{
    String name;
    int year;
    String address;
    Employee1(String n,int yr,String ad){
        name=n;
        year=yr;
        address=ad;
    }
    void print_inf(){
        System.out.println("name : "+name+" year :"+year+" Address :"+address +"\n" );
    }
}
public class Employee {
    public static void main(String args[]){
    Employee1 obj1=new Employee1("Robert",1994 ,"64C- WallsStreat");
    obj1.print_inf();
    Employee1 obj2=new Employee1("sam",2000 ,"68D- WallsStreat");
    obj2.print_inf();
    Employee1 obj3=new Employee1("john",1999 ,"26B- WallsStreat");
    obj3.print_inf();
     }
}
