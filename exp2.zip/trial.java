/*class  Student{
    int i=10;
    String str="Gayu";
    void display(){
        System.out.println(" in class trial ");
    }
}
public class trial{
    public static void main(String args[]){
        Student s1=new Student();
        System.out.println("i="+s1.i+"str="+s1.str);
        s1.display();
    }
}

 */
class Student{
    int roll;
    String name;
    void insert(int i,String str){
        roll=i;
        name=str;
    }
    void display(){
        System.out.println("Roll "+roll+"name "+name);
    }
}
public class trial {
    public static void main(String args[]){
        Student obj1=new Student();
        obj1.insert(10,"Gayu");
        obj1.display();
        Student obj2=new Student();
        obj2.insert(11,"ru");
        obj2.display();
    }
}
