
 class rooom1 {
    int roomno;
    String roomtype;
    float roomarea;
    int Ac;

    void setdata(){
        roomno=100;
        roomtype="luxury";
        roomarea=1000.12f;
        Ac=5;
    }
    void dispalydata(){
        System.out.println("Printing information ....");
        System.out.println("room no "+roomno+" room type "+roomtype+" room area "+roomarea+" no of Ac "+Ac);

    }
}
public class room {
    public static void main(String args[]){
        rooom1 obj1=new rooom1();
        obj1.setdata();
        obj1.dispalydata();
        //System.out.println("room type"+ obj1.roomtype);
    }
}

/*
Printing information ....
room no 100 room type luxury room area 1000.12 no of Ac 5
 */