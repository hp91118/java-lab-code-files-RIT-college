/*
5)	Write a program to
-create the Class Bank with the static variable balance with initial value as 500 and
 two methods Deposit () and Withdraw ()
- Create 3 objects of class for three family members.
- and have the shared transaction on shared bank account.
-check the mini balance is 100 Rs. While withdrawing.

 */
class bank1 {
    static int  bal=500;
    void Deposit(){
        bal=bal+300;
        System.out.println("Amount Deposited \n bal :"+bal);
    }
    void Withdraw(){
        bal=bal-100;
        System.out.println("Amount withdrawed \n bal :"+bal);
    }
}
public class bank{
    public static void main(String args[]){
        bank1 obj1=new bank1();
        bank1 obj2=new bank1();
        bank1 obj3=new bank1();
        obj1.Deposit();
        obj1.Withdraw();
        System.out.println("Balance in account :"+obj1.bal);//bal is shared among all instances ^ ^
        System.out.println("Balance in account :"+obj2.bal);
        System.out.println("Balance in account :"+obj3.bal);
    }
}
/*
Amount Deposited
 bal :800
Amount withdrawed
 bal :700
Balance in account :700
Balance in account :700
Balance in account :700
 */