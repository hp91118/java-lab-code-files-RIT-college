
import java.util.Scanner;
class Average {
    float avg;
    void calculate(int num1, int num2 ,int num3){
        avg=(num1+num2+num3)/3;

    }
    void print(){
        System.out.println("Average :"+avg);
    }

}
class Average_1{
    public static void main(String args[]){
        Average obj=new Average();
        int num1,num2,num3;
        System.out.println("Enter num1 :");
        Scanner sc = new Scanner(System.in);
        num1 =sc.nextInt();
        System.out.println("Enter num2 :");
        num2 =sc.nextInt();
        System.out.println("Enter num3 :");
        num3 =sc.nextInt();
        obj.calculate(num1,num2,num3);
        obj.print();


    }
}
/*
op
Enter num1 :
12
Enter num2 :
13
Enter num3 :
14
Average :13.0

 */
