import java.util.Scanner;

/*4)	Java program which creates Stakeholder class
 as a main class and create two other classes such as
 faculty and student. Read the details of faculty and
  students in main, pass these details to method
   defined
   in respective class, print those details.
 */
class faculty{
    void fac_display(int i,int a, String n){
        System.out.println(" Faculty Details \n"+"id "+i+" age "+a+" name "+n);
    }

}
class student{
    void stud_display(int i,int a,String n,int c){
        System.out.println(" Student Details \n"+"id "+i+" age "+a+" name "+n+" class "+c);



    }
}

public class stakeholder {
    public static void main(String args[]){
        int id,age;
        String name;
        System.out.println("Enter faculty details(id age name) :");
        Scanner sc=new Scanner(System.in);
        id=sc.nextInt();
        age=sc.nextInt();
        name=sc.next();
        faculty obj1=new faculty();
        obj1.fac_display(id,age,name);

        student obj2=new student();
        obj2.stud_display(2010044,19,"gayati gomewadikar ",12);

    }
}

/*
Enter faculty details(id age name) :
201
40
Vinaya
 Faculty Details
id 201 age 40 name Vinaya
 Student Details
id 2010044 age 19 name gayati gomewadikar  class 12
 */