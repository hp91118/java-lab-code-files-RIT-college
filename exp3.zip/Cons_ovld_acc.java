class Create_Account{
   int account_no=100;
   int bal=500;
   String dob="1-1-2010";
    Create_Account(){
        System.out.println("Account information :"+account_no+"\n"+bal+"\n"+dob);

    }
    Create_Account(int account_no, int bal){
        this.bal=bal;
        this.account_no=account_no;
        System.out.println("Account information :"+account_no+"\n"+bal+"\n"+dob );
    }
    Create_Account(int account_no,int bal,String dob){
        this.account_no=account_no;
        this.bal=bal;
        this.dob=dob;
        System.out.println("Account information :"+account_no+"\n"+bal+"\n"+dob );

    }

}


public class Cons_ovld_acc {
    public  static  void main(String args []){
        Create_Account obj1=new Create_Account();
        Create_Account obj2=new Create_Account(100,20000);
        Create_Account obj3=new Create_Account(200,300000,"09-12-2002");
    }
}
/*op
Account information :100
500
1-1-2010
Account information :100
20000
1-1-2010
Account information :200
300000
09-12-2002

Process finished with exit code 0

 */