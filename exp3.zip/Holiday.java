
// check this code ????
public class Holiday {
    String name;
    int day;
    String month;

    Holiday(String name, int day, String month) {
        this.name = name;
        this.day = day;
        this.month = month;
        System.out.println("In cons");
    }

   public boolean isSameMonth(Holiday obj2) {
       System.out.println("this.month .equals((obj2.month))");
       return this.month .equals((obj2.month)) ;


    }

    public static void main(String args[]) {
        Holiday obj1 = new Holiday("Gayu", 18, "December");
        Holiday obj2 = new Holiday("Avani", 26, "December");

        // System.out.println(obj1.equals(obj2));
    }
}

