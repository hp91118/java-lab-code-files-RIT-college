
// using this keyword
 class chaining {
    String str;

chaining(){
    this("Gayatri ");
    int num1=2010044;
    System.out.println("In Default constructor "+num1);
}
chaining(String str){
    this.str=str;
    System.out.println("In param constructot ,parameter passed :"+this.str);
}
}
class Cons_chaining{
    public static void main(String args[]){
        chaining obj1=new chaining();
    }
}
