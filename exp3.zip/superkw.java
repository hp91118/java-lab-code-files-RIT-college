/*
It is used to refer to an instance variable of the immediate parent class.
It is used to invoke a method of the immediate parent class.
It is used to invoke a constructor of immediate parent class.
 */
class Parent{
    String name="Anant";
    int age=40;
    void method(){
        System.out.println("Parent class method ");
    }
    Parent(){
        System.out.println("This is Parent constructor ");
    }
}
class Child extends Parent{
    String name="Gayatri";
    int age=19;
    void method(){
        System.out.println("Child class method");
    }
    Child(){
        super();
        System.out.println("This is child constructor ");

    }
    void print(){
        System.out.println("Parent class name :"+super.name+" Parent class age "+super.age);
        System.out.println("Child class name :"+name+" Child  class age "+age);
        super.method();//parent is invoked
        method();//child is invoked
    }
}
public class superkw {
    public static void main(String args[]){
        Child obj1=new Child();
        obj1.print();
    }
}
/*
Parent class name :Anant Parent class age 40
Child class name :Gayatri Child  class age 19
Parent class method
Child class method


 */
