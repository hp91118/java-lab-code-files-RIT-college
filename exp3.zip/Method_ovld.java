/*Let's say you have an integer array and a string array. You have to write a single
        method printArray that can print all the
        elements of both arrays. The method should be able to
        accept both integer arrays or string arrays.

 */
class arr{
    int i;
    void printArray(int array1[]){
        for(i=0;i<array1.length;i++){
            System.out.println(i+" Array element:"+array1[i]);
        }
    }
    void printArray(String array2[]){
        for(i=0;i<array2.length;i++){
            System.out.println(i+" Array element:"+array2[i]);
        }

}
}
public class Method_ovld {
    public static void main(String args[]){
        arr obj1=new arr();
        int intArray[]={1,2,3,4,5};
        obj1.printArray(intArray);
        String strArray[]={"M","O","M"};
        obj1.printArray(strArray);
    }
}