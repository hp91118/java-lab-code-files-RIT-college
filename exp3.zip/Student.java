/*
Create a class named 'Student' with String variable 'name' and integer variable 'roll_no'.
create 2 objects of class Student and initialize the Students
objects by parametrized constructor. And Display the information of both students
 */
class Student1{
    String name;
    int roll;
    Student1(int roll,String name){
        this.roll=roll;
        this.name=name;
    }
    void display(){
        System.out.println("name : "+name);
        System.out.println("roll :"+roll);
    }
}
public class Student {
    public static void main(String args[]){
        Student1 obj1=new Student1(2010044,"Gayatri");
        Student1 obj2=new Student1(12,"Rushi");
        obj2.display();
        obj1.display();
    }
}
/*
name : Rushi
roll :12
name : Gayatri
roll :2010044

 */
