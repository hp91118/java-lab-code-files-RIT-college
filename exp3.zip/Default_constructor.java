class Default {
    Default(){
        System.out.println("This is default constuctor ");
    }
}
class Default_constructor{
    public static void main(String args[]){
        Default obj1=new Default();// This is default constuctor

    }

}

