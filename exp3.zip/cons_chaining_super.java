class Parent1{
    Parent1(){
        System.out.println("This is Parent class default cons");
    }
    Parent1(int num){
        System.out.println("Parent class parameterised cons  "+num);
    }

}
class Child1 extends Parent1{
    Child1(){
        System.out.println("This is child class default cons ");
    }
    Child1(int num1){
        super(30);
        System.out.println("This is child class parameterised cons  "+num1);
    }
}
public class cons_chaining_super {
    public static void main(String args []){
        Child1 obj1=new Child1();
        Child1 obj2=new Child1(5);
    }

}
/*
When we create an object of a child class, a corresponding object of the
superclass is implicitly created which is referred to by the super keyword.
Even if we don't invoke the parent class constructor using super(); in the example above, the same output is generated because the child constructor implicitly
calls the parent class default constructor.

This is Parent class default cons
This is child class default cons
Parent class parameterised cons  30
This is child class parameterised cons  5
 */
