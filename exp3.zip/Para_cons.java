class Parameterised{
    int id;
    String name;
    Parameterised(int id,String name)
    {
        System.out.println("In parameterised constructor ");
        this.id=id;
        this.name=name;
    }
}
class para_cons {
    public static void main(String args[]) {
        Parameterised obj1 = new Parameterised(2010044, "Gayatri");
        System.out.println("id "+obj1.id+" name "+obj1.name);
    }
}

/*
In parameterised constructor
id 2010044 name Gayatri

 */