
/*

Constructor Overloading
Write a program to print the names of students by creating a Student class.
If no name is passed while creating an object of Student class, then the name should be "Unknown",
otherwise the name should be equal to the String value passed while creating object of Student class.

 */


class Stu{
String Stu_name;
Stu(){
    Stu_name="Unknown";
    System.out.println(Stu_name);
}
Stu(String Stu_name){
    this.Stu_name=Stu_name;
    System.out.println(Stu_name);
}

}
public class Cons_ovld {
    public static void main(String main[]){
        Stu obj1=new Stu("Gayatri");
        Stu obj2=new Stu();

    }

}
