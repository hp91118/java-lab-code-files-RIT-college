import java.util.Scanner;
class Area{
    int base,hgt,side;
    double area;
    void calculate_area(int base ,int hgt){
        this.base=base;
        this.hgt=hgt;
        area=base*hgt*0.5;
        System.out.println("Area of Triangle :"+area);

    }
    void calculate_area(int side){
        this.side=side;
        area=side*side;
        System.out.println("Area of Square :"+area);
    }
}


public class Cal_area {
    public  static void  main(String args[]){
        Area obj1=new Area();
        obj1.calculate_area(500 ,200);
        obj1.calculate_area(20);

    }
}
/*
Area of Triangle :50000.0
Area of Square :400.0

Process finished with exit code 0
 */