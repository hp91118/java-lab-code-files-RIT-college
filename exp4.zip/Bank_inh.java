class Parent{
    static int bank_balance=1000;
    void deposit(){
        bank_balance=bank_balance+1000;
        System.out.println("Money Deposited is 1000");

    }
    void withdraw(){
        bank_balance=bank_balance-200;
        System.out.println("Money withdrawed is 200");
    }

}
class Son1 extends Parent{
    void display(){
        System.out.println("Final bank bal "+bank_balance);
    }

}

public class Bank_inh {
    public static void main(String args[]){
        Son1 obj1= new Son1();
        Son1 obj2=new Son1();
        obj1.deposit();//add 1000
        obj2.withdraw();//dedeuct 200
        obj1.display();

    }
}

/*
Money Deposited is 1000
Money withdrawed is 200
Final bank bal 1800

 */