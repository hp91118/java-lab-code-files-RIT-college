//method overriding
class Vehicle{
    void display(){
        System.out.println("This is vehicle class ");
    }
}
class Avenger extends Vehicle{
    void display(){
        System.out.println("This Avenger");
    }
}
class Fascino extends Vehicle{
    void display(){
        System.out.println("This is Fascino");
    }
}
class Harley_Davidson extends Vehicle{
    void display(){
        System.out.println("This is Harley Davidson");
    }

}

public class Method_overriding {
    public static void main(String args[]){
        Avenger obj1=new Avenger();
        obj1.display();
        Fascino obj2=new Fascino();
        obj2.display();
        Harley_Davidson obj3=new Harley_Davidson();
        obj3.display();
    }
}
/*
This Avenger
This is Fascino
This is Harley Davidson

 */