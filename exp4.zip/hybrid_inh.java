class Grandfather{
    void showG(){
        System.out.println("I am Grandfather");
    }
}
class Father extends Grandfather{
    void showF(){
        System.out.println("I am Father");
    }
}
class Son extends Father{
    void showS(){
        System.out.println("I am Son");
    }
}
class Daughter extends Father {
    void showD(){
        System.out.println("I am Daughter");
    }
}
public class hybrid_inh {
    public static void main(String args[]){
        Son obj1=new Son();
        Daughter obj2=new Daughter();
        obj1.showS();
        obj1.showF();
        obj1.showG();
// by using both son and daughter we can access father and grandfather
        obj2.showD();
        obj2.showF();
        obj2.showG();
    }
}
/*
I am Son
I am Father
I am Grandfather
I am Daughter
I am Father
I am Grandfather

 */
