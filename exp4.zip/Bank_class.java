
/*
Consider a scenario where Bank is a class that provides functionality to get the rate of interest.
 However, the rate of interest varies according to banks. For example, SBI, ICICI and AXIS banks
 could provide 8%, 7%, and 9% rate of interest.
 */
import java.util.Scanner;
class Bank{
    float amt;
    void getInterestOf(float amt){
        this.amt=amt;
    }
}
class SBI extends Bank{

    void getInterestOf(float amt) {
        float interest= (float) (amt*1*0.08);
        System.out.println("SBI ha has 8% interest rate \n Interest is "+interest);
    }
}
class ICICI extends Bank{

    void getInterestOf(float amt) {
        float interest=(float)(amt*1*0.07);
        System.out.println("ICICI has 7% interest rate \n Interest is "+interest);
    }
}
class AXIS extends Bank{

    void getInterestOf(float amt) {
        float interest=(float)(amt*1*0.09);
        System.out.println("AXIS has 9% interest rate \n Interest is "+interest);
    }
}

public class Bank_class {
    public static void main(String args[]){
        System.out.println("Enter principle amount(consider interest for one yr) :");
        Scanner sc=new Scanner(System.in);
        float amt=sc.nextFloat();
        SBI s1=new SBI();
        s1.getInterestOf(amt);
        ICICI s2=new ICICI();
        s2.getInterestOf(amt);
        AXIS s3=new AXIS();
        s3.getInterestOf(amt);

    }
}
/*
Enter principle amount(consider interest for one yr) :
1000
SBI ha has 8% interest rate
 Interest is 80.0
ICICI has 7% interest rate
 Interest is 70.0
AXIS has 9% interest rate
 Interest is 90.0

 */
