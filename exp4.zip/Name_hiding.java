class Parent2{
    String name="Atul";
}
class child2 extends Parent2{
    String name="Rushi";
    void printName(){
        System.out.println("Parent name is "+super.name);
        System.out.println("Child name is "+name);

    }
}

public class Name_hiding {
    public static void main(String args []){
        child2 obj1=new child2();
        obj1.printName();

    }
}
/*
Parent name is Atul
Child name is Rushi
 */
