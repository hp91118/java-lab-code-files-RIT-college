/*
i)	Java Program for simple Inheritance

Class Programmer with bouns_salary field extends the class Employee with salary field.
Scan and print the salary along with bonus for programmer.


 */
class Programmer{
    int bonus=50000;
}
class Employee extends Programmer{
    float salary=100000;

    void print_v(){
        System.out.println("Salary "+salary);
        System.out.println("Bonus "+bonus);
        //System.out.println("Salary with bonus "+Float.parseFloat(salary+bonus));
        salary=salary+bonus;
        System.out.println("Salary with bonus "+salary);
    }
}
public class Simple_inh {
    public static void main(String args[]){
        Employee obj1=new Employee();
        obj1.print_v();

    }
}
/*
op
Salary 100000.0
Bonus 50000
Salary with bonus 150000.0

 */
