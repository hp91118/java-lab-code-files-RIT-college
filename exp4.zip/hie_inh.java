
class Employee1{//base class
    int basic_sal=50000;
    double P_DA=1.5*basic_sal;
    double T_DA=0.8*basic_sal;
}
class Perm_employee extends Employee1{
    void sal(){
        double sal=basic_sal+P_DA;
        System.out.println("Perm_emp sal:"+sal);
    }
}
class Temp_employee extends Employee1{
    void sal(){
        double sal=basic_sal+T_DA;
        System.out.println("Temp_emp sal :"+sal);
    }

}
public class hie_inh{
    public static void main(String args[]){
            Perm_employee obj1=new Perm_employee();
            Temp_employee obj2=new Temp_employee();
            obj1.sal();
            obj2.sal();
            System.out.println(obj2.equals(obj1));
    }
}
