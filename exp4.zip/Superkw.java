class Parent1{
    Parent1(){
        System.out.println("I am parent class constructor ");
    }
}
class Child1 extends Parent1{
    Child1(){
        super();
        System.out.println("I am child class constructor ");
    }
}

public class Superkw {
    public static void main(String args []){
        Child1 obj1=new Child1();

    }
}
/*
I am parent class constructor
I am child class constructor

Process finished with exit code 0

 */
