class Maruti_800{
    void speed(){
        int Speed=100;
        System.out.println("vehicle speed :"+Speed);
    }
}
class Maruti extends Maruti_800{
    String Brand="TATA";
    void brand(){
        System.out.println("Brand "+Brand);
    }
}
class car extends Maruti{
    String vehicle="car";
    void vehicle_type(){
        System.out.println("Vehicle type "+vehicle);
    }
}
public class Multilevel_inh {
    public static void main(String args[]){
        car obj1=new car();
        obj1.vehicle_type();
        obj1.brand();
        obj1.speed();

    }
}
/*
classpath C:\Users\aquar\IdeaProjects\project4\out\production\project4 Multilevel_inh
Vehicle type car
Brand TATA
vehicle speed :100

 */
