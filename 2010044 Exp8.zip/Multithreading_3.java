class Multithreading extends  Thread{
    public void run(){
        for(int i=0;i<=5;i++){
            try{
                Thread.sleep(1000);

            }
            catch (InterruptedException e) {
                System.out.println(e);
            }

            System.out.println("Thread "+i);
        }

    }

}

public class Multithreading_3 {
    public static void main(String args[]){
        Multithreading obj1=new Multithreading();
        obj1.start();
        Multithreading obj2=new Multithreading();
        obj2.start();
    }
}

/*
Thread 0
Thread 0
Thread 1
Thread 1
Thread 2
Thread 2
Thread 3
Thread 3
Thread 4
Thread 4
Thread 5
Thread 5

Process finished with exit code 0

 */