
class Multithreading1 extends Thread  {
    public void run(){
        System.out.println("Hello world :)");
        System.out.println(Thread.currentThread().getName()); // Thread-1
        System.out.println(Thread.currentThread().getId());// 19
    }

}

public class Multithreading_1Thread {
    public static void main(String args[]){
        int n=10;
        for(int i=0;i<=5;i++){
            Multithreading1 obj1=new Multithreading1();
            obj1.start();
            System.out.println("Hello");
            System.out.println(Thread.currentThread().getName());

        }
    }

    /*
    Hello world :)
Hello world :)
Hello world :)
Hello world :)
Hello world :)
Hello world :)

Process finished with exit code 0

     */



}
