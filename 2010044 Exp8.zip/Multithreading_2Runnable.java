class Multithreading2 implements  Runnable{
    public void run(){
        System.out.println("Multithraeding :)");

    }

}

public class Multithreading_2Runnable {
    public static void main(String args[]){
       Multithreading2 objr=new Multithreading2();
        Thread obj=new Thread(objr);
        obj.start();


    }

}
