public class AnimalMultiThreadDemo {
    public static void main(String[] args) throws Exception{
        // Make object of  Runnable
        AnimalRunnable anr = new AnimalRunnable();
        Thread cat = new Thread(anr);
        cat.setName("Cat");
        Thread dog = new Thread(anr);
        dog.setName("Dog");
        Thread cow = new Thread(anr);
        cow.setName("Cow");
        System.out.println("Thread State of Cat before calling start: "+cat.getState());
        cat.start();
        dog.start();
        cow.start();
        System.out.println("Thread State of Cat in Main method before Sleep: " + cat.getState());
        System.out.println("Thread State of Dog in Main method before Sleep: " + dog.getState());
        System.out.println("Thread State of Cow in Main method before Sleep: " + cow.getState());
        Thread.sleep(10000);
        System.out.println("Thread State of Cat in Main method after sleep: " + cat.getState());
        System.out.println("Thread State of Dog in Main method after sleep: " + dog.getState());
        System.out.println("Thread State of Cow in Main method after sleep: " + cow.getState());
    }
}

class AnimalRunnable implements Runnable {
    @Override
    public void run() {
        for (int x = 1; x < 4; x++) {
            System.out.println("Run by " + Thread.currentThread().getName());
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }
        System.out.println("Thread State of: "+ Thread.currentThread().getName()+ " - "+Thread.currentThread().getState());
        System.out.println("Exit of Thread: "
                + Thread.currentThread().getName());
    }
}


/*
"C:\Program Files\Java\jdk-18.0.2.1\bin\java.exe" "-javaagent:C:\Program Files\JetBrains\IntelliJ IDEA Community Edition 2022.2.1\lib\idea_rt.jar=57905:C:\Program Files\JetBrains\IntelliJ IDEA Community Edition 2022.2.1\bin" -Dfile.encoding=UTF-8 -Dsun.stdout.encoding=UTF-8 -Dsun.stderr.encoding=UTF-8 -classpath C:\Users\aquar\IdeaProjects\project8\out\production\project8 AnimalMultiThreadDemo
Thread State of Cat before calling start: NEW
Run by Cat
Thread State of Cat in Main method before Sleep: RUNNABLE
Run by Cow
Thread State of Dog in Main method before Sleep: BLOCKED
Thread State of Cow in Main method before Sleep: TIMED_WAITING
Run by Dog
Run by Cow
Run by Cat
Run by Dog
Run by Cat
Run by Cow
Run by Dog
Thread State of: Cow - RUNNABLE
Exit of Thread: Cow
Thread State of: Cat - RUNNABLE
Exit of Thread: Cat
Thread State of: Dog - RUNNABLE
Exit of Thread: Dog
Thread State of Cat in Main method after sleep: TERMINATED
Thread State of Dog in Main method after sleep: TERMINATED
Thread State of Cow in Main method after sleep: TERMINATED

Process finished with exit code 0

 */
