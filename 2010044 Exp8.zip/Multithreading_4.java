
class multithreading_1 extends  Thread{
    public void run(){
        System.out.println(Thread.currentThread().getName());
        System.out.println(Thread.currentThread().getPriority());
    }

}



public class Multithreading_4 {
    public static void main(String args[]) throws InterruptedException{
        multithreading_1 t1=new multithreading_1();
        multithreading_1 t2=new multithreading_1();
        t1.setName("Rit");
        t2.setName("Islampur");
        t1.setPriority(6);
       // t1.setPriority(Thread.MIN_PRIORITY); 1
       // t1.setPriority(Thread.MAX_PRIORITY); 10
        t2.setPriority(8);
        t1.start();
        System.out.println("isAlive :"+t1.isAlive());
        t2.start();
        t1.join();
        System.out.println("isAlive after join :"+t1.isAlive());
        t2.join();// wait to join in main trhread

        System.out.println("Bye ....");

    }
}
/*
Rit
6
isAlive :true
isAlive after join :false
Islampur
8
Bye ....
 */
