class a extends Thread{
    public void run(){
        for(int i=1;i<=5;i++){
            System.out.println("Good morning  ");
            try{Thread.sleep(1000);}catch (Exception e){}

        }
    }
}
class b extends Thread{
    public void run(){
        for(int i=1;i<=5;i++){
            System.out.println("TY CSIT  ");
            try{Thread.sleep(1000);}catch (Exception e){}
        }
    }
}



public class Telusko {
    public static void main(String args[]){
        a obj1=new a();
        b obj2=new  b();
        obj1.start();
      //  try {
        //    Thread.sleep(10);// do not 1000
       // }catch (Exception e){}
        obj2.start();

    }
}
/*
Good morning
TY CSIT
Good morning
TY CSIT
Good morning
TY CSIT
Good morning
TY CSIT
Good morning
TY CSIT

Process finished with exit code 0

 */
