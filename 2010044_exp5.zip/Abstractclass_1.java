/*
Take abstract class Animal with abstract method MakeSound() and non abstract method eat()
with its implementation.  The class Dog inherits the Abstract class Animal and do implementation
 of MakeSound method. In main class create the object of Dog to see the implementation of run method
 and MakeSound Method
 */
abstract class Animal{
    abstract void MakeSound();
    void eat(){
        System.out.println("Eating");
    }
        }
class Dog extends Animal{
    void MakeSound(){
        System.out.println("Making sound ");
    }
}

public class Abstractclass_1 {
public static void main(String args[]){
    Dog obj1=new Dog();
    obj1.MakeSound();
    obj1.eat();
}

}
