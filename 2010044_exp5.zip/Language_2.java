import  java.util.Scanner;
interface Language{
     void getType();
    void getVersion();
}
class Demo implements Language{
    public void getType(){
        System.out.println("Type is object oriented ");
    }
    public void getVersion(){
        System.out.println("This is 5 th version ");
    }
}
public class Language_2 {
    public static void main(String args[]){
        Language obj1=new Demo();
        obj1.getType();
        obj1.getVersion();
    }
}
/*
Type is object oriented
This is 5 th version

 */
