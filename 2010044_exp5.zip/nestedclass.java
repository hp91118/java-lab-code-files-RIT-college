
/*
You are given a class “Solution” and an inner class
“CheckPrime”. The main method of class Solution takes
an integer as input. The prime method in CheckPrime
class checks whether a number is prime or not.
ou have to call the method prime of the class
CheckPrime
from the main method of the class Solution.
 */
import java.util.Scanner;
class Solution {
    int num;
    void takeIp(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter number :");
        num=sc.nextInt();
    }
    class Checkprime{
        void prime(){
            int c=0;
            for(int i=2;i<num;i++){
                if(num%i==0)
                { c=c+1;
                break;}
            }
            if(c==0){
                System.out.println("Prime num");
            }
            else{
                System.out.println("Not prime");
            }
        }
    }
}
public class nestedclass {
    public static void main(String args[]){
        Solution obj1=new Solution();
        Solution.Checkprime obj2=obj1.new Checkprime();
        obj1.takeIp();
        obj2.prime();
    }
}
/*
Enter number :
35
Not prime

 */
