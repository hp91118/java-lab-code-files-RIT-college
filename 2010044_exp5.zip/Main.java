interface interface1{
    int num1=20;
     void show();
}
class class_1 implements interface1{
    public void show(){
        System.out.println("this is show method "+num1);
    }
}


public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");

    interface1 obj1=new class_1();
    obj1.show();
}}