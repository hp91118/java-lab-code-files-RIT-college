/*
You are given an interface AdvancedArithmetic which contains a
 method signature int divisor_sum(int n). You need to write a
  class called MyCalculator which implements the interface.
divisorSum function just takes an integer as input and return
 the sum of all its divisors. For example divisors of 6 are 1, 2,3
 and 6, so divisor_sum should return 12.
Sample Input
6
Sample Output
I implemented: AdvancedArithmetic
12
Explanation
Divisors of 6 are 1,2,3 and 6. 1+2+3+6=12.
 */
import java.util.Scanner;
interface AdvancedArithmetic{
    int divisor(int n);
}
class MyCalculator implements  AdvancedArithmetic{
    public int divisor(int n){
        int sum=0,i=0;
        for(i=1;i<=n;i++){
            if(n%i==0){
                sum=sum+i;
            }}
        return sum;
    }
}
public class Arithmetic_1 {
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        AdvancedArithmetic obj1=new MyCalculator();
        int sum=obj1.divisor(n);
        System.out.println("I implemented: AdvancedArithmetic\n"+sum);
    }
}
/*
6
I implemented: AdvancedArithmetic
12

 */
