
/*
Take abstract class Animal with abstract method run().
The class Dog inherits the Abstract class Animal
and do implementation of run method.
 In main class create the object of Dog to see the implementation of run method
 */
abstract class Animal1{
    abstract void run();// abs method
}
class Dog1 extends Animal1{
    void run(){
        System.out.println("Dog is running ,,,,");
    }
}
public class Abstractclass2 {
    public static void main(String args []){
        Dog1 obj1=new Dog1();
        obj1.run();
    }

}
