
interface Camera
{
    void click();
    void record();
}
interface Player{
    void play();
    void pause();
    void stop();
}
class Smartphone implements Camera,Player{
    public void click(){
        System.out.println("Photo clicked ");
    }
    public void record(){
        System.out.println("Video recorded ");
    }
    public void play(){
        System.out.println("Player played ");
    }
    public void pause(){
        System.out.println("Player paused ");
    }
    public void stop(){
        System.out.println("Player stopped ");
    }

}

public class Multiplein_interface {
    public static void main(String args[]){
        Smartphone obj1=new Smartphone();
        obj1.click();
        obj1.record();
        obj1.play();
        obj1.pause();
        obj1.stop();
    }
}
/*
Photo clicked
Video recorded
Player played
Player paused
Player stopped

 */
