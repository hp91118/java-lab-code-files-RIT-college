import java.util.*;

public class linkedlist1 {
    public static void main(String args []){
        LinkedList<Integer>list=new LinkedList<>();
        list.add(0);
        list.add(10);
        list.add(20);
        list.add(30);
        list.add(40);
        list.add(50);
        list.add(60);
        list.add(70);
        list.add(80);
        list.add(90);
        //for printing
        System.out.println("using for loop");
        for(int i: list){
            System.out.println(i);
        }
        Iterator itr=list.iterator();
        System.out.println("using iterator");
        while (itr.hasNext()){
            System.out.println(itr.next());
        }
        //System.out.println(list);
        list.add(10,100);
        System.out.println("after adding 100"+list);
        System.out.println("size :"+list.size());
        System.out.println("element at 8th pos "+list.get(8));
        System.out.println("using for loop and get fun");
        for(int i=0;i<list.size();i++){
            System.out.println(list.get(i));
        }
        //set() method
        System.out.println("Changed elements of list "+list.set(8,800));
        System.out.println("after set method"+list);
        System.out.println("Removing element at 8 th pos is  "+list.remove(8));
        System.out.println("after removing 800 using index "+list);
        list.add(8,8000);
        list.addFirst(1000);
        list.addLast(45);
        System.out.println("line 42 list "+list);
        System.out.println("size of list"+list.size());
        System.out.println("clone shallow copy "+list.clone());
        System.out.println("contains 8000 or not :"+list.contains(8000));
        //descending iterator
        Iterator itrd=list.descendingIterator();
        System.out.println("Elements in reverse order");
        while(itrd.hasNext()){
            System.out.println(itrd.next());
        }
        System.out.println("head"+list.element());
        System.out.println("first"+list.getFirst());
        System.out.println("last"+list.getLast());
        //peek gives first element peelFirst gives first ele else null sim peekLast
        System.out.println("peek:"+list.peek());
        System.out.println("index of element 10 :"+list.indexOf(10));
        System.out.println("lastindexof of element 20 :"+list.lastIndexOf(20));
        //offer()
        System.out.println("adding 9 using offer() at tail :"+list.offer(9));
        System.out.println("adding 99 using offerFirst()"+list.offerFirst(99));

        System.out.println(list);
        // poll,pollFirst() and remove removes head   and pollLast()   else  returns null
        System.out.println("using poll removed ele :"+list.poll());
        //removeFirst(),removeLast() remove and returns  next element
        System.out.println(list.removeFirst());
        list.clear();//rtn void
        System.out.println(list);// empty list




    }
}
