import com.sun.source.tree.WhileLoopTree;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import  java.util.Map;

public class hashtable1 {
    public static void main(String args []) {
        Hashtable<String, Integer> h1 = new Hashtable<String, Integer>();
        //key should be unique v
        //values can be duplicate
        //no null key or value
        h1.put("gayatri",44);
        h1.put("rushi",101);
        h1.put("rajeev",121);
        h1.put("netra",1);
        h1.put("manas",4);
        //printing object
        System.out.println(h1);
        // only values get print
        Iterator itr=h1.elements().asIterator();
        while (itr.hasNext()){
            System.out.println(itr.next());
        }

        System.out.println("get(key) method for rushi :"+h1.get("rushi"));
        System.out.println("replace(key,valnew):"+h1.replace("rajiv",12));
        System.out.println(h1);
        System.out.println("hashcode value of map "+h1.hashCode());
        //contains returns boolean if value is matched with some key
        System.out.println("contains(value) 1 :"+h1.contains(1));
        //contains returns boolean if value is matched with some key
        System.out.println("containskey(key) netra :"+h1.containsKey("netra"));

        //adding one more
        h1.put("anant",1);
        System.out.println(h1);
        //containsValue(val) Returns true if this hashtable
        // maps one or more keys to this value.
        System.out.println("containsValue(val) 1...1 is value of more than 1 key :"+h1.containsValue(1));
        //print all keys
        System.out.println("printing all keys ie string using Enumeration and keys() ");
        Enumeration<String> keys=h1.keys();
        while(keys.hasMoreElements()){
            System.out.println(keys.nextElement());
        }
        //print all values
        System.out.println("printring all values ie integers using Enumeration and elements()");
        Enumeration<Integer> values =h1.elements();
        while(values.hasMoreElements()){
            System.out.println(values.nextElement());
        }
        System.out.println("Removing key rajeev using remove(key)");
        h1.remove("rajeev");
        System.out.println("printing all entries of hashtable :");
        for(Map.Entry m:h1.entrySet()){
            System.out.println(m.getKey()+" "+m.getValue());
        }
        System.out.println("Size : "+h1.size());
        String s=h1.toString();
        System.out.println("toString :"+s);
        // Now creating an Enumeration object
        // to store keys
        Enumeration<String> en=h1.keys();
        // Condition holds true till there is
        // single key remaining
        while(en.hasMoreElements()){
            // Getting key
            String key=en.nextElement();
            // Printing key and value corresponding to
            // that key
            System.out.println("key "+key+" val"+h1.get(key));
        }






    }

}
