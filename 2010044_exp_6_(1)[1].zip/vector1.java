
    import java.util.*;
    public class vector1 {
        public static void main(String main[]){
            Vector<Integer> v1=new Vector<>();
         //adding elements
            v1.add(2);
            v1.add(12);
            v1.add(22);
             v1.add(25);
             v1.add(26);
             v1.add(27);
             v1.add(28);
             v1.add(29);
             v1.add(5,500);//adding element at 5 th position
             //adding element at last
            v1.addElement(10);
            System.out.println("Capacity() of vector :"+v1.capacity());
            System.out.println("clone of vector :"+v1.clone());
         //printing elements
         System.out.println("Using obj :"+v1);
         //using iterator
         Iterator itr =v1.iterator();
            System.out.println("Using iterator :");
         while(itr.hasNext()){

             System.out.println(itr.next());
         }
         //using enumretor
            System.out.println("Using enumerator :");

         Enumeration en=v1.elements();
         while (en.hasMoreElements()){
             System.out.println(en.nextElement());   //more specific Elements methods
         }
            System.out.println("element at 5 th posiyion using elementAt() :"+v1.elementAt(5));
            System.out.println("element at 5 th posiyion using get() :"+v1.get(5));
            System.out.println("first element using firstElement :"+v1.firstElement());
            //insertElementAt(ele,index)
           v1.insertElementAt(501,5);
           System.out.println(v1);//501 at 5 th loc
            System.out.println("isEmpty :"+v1.isEmpty());
            System.out.println("last element "+v1.lastElement());
            //setting element 222 at 10 th loc
            v1.set(10,222);
            v1.setElementAt(55,5);
            System.out.println("after set (55,5)"+v1);
            //capacity of vector
            System.out.println(v1.capacity());
            System.out.println("current size :"+v1.size());
            System.out.println("sublist "+v1.subList(2,8));
            System.out.println("removing element at 5th loc "+v1.remove(5));
            System.out.println(v1);
            //removeElementAt(index)
            //clearing vector by clear()/ removeAllElements()
             v1.clear();
            System.out.println("after removing"+v1);

        }// main end

    }//class end

