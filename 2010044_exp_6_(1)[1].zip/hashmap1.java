// hashmap implements map interface
//unique keys  ---->one null key and con have multiple null values
//non synchronised
import java.util.*;
public class hashmap1 {
    public static void main(String args[]){
        HashMap<Integer,String> h=new HashMap<>();
        h.put(44,"gayu");
        h.put(43,"shweta");
        h.put(33,"pranoti");
        h.put(22,"shravani");
        h.put(41,"pratiksha");
        System.out.println("hashmap :"+h);
        System.out.println("hashmap size :"+h.size());
        System.out.println("hashmap containskey(shravani):"+h.containsKey("shravani"));
        //remove
        h.remove(22);
        //traversing
        System.out.println("after removing key 22");
        for(Map.Entry m: h.entrySet()){
            System.out.println("key :"+m.getKey()+" value :"+m.getValue());
        }
        //access an item
        System.out.println("using get(key) 33 "+h.get(33));
        System.out.println("cloning "+h.clone());
        h.clone();
        System.out.println("Traversing through keys ");
        for(int i:h.keySet()){
            System.out.println(i);
        }
        System.out.println("Traversing through values  ");
        for(String s:h.values()){
            System.out.println(s);
        }
        System.out.println("printing keys and values using keyset :");
        for (int key: h.keySet()){
            System.out.println("key :"+key+" value :"+h.get(key));
        }
    //replacing value for 33
       h.replace(33,"pranoti","gayatri");
        System.out.println(h);
        //clearing
         h.clear();
         System.out.println("after clear() "+h);

    }
}
