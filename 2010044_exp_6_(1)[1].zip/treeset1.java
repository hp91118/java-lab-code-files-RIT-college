import java.util.*;

public class treeset1 {
    public  static void main(String args []){
        TreeSet<Integer> t=new TreeSet<>();
        t.add(10);
        t.add(20);
        t.add(1);
        System.out.println(t);//dispaly is asc order
        System.out.println("size :"+t.size());
        System.out.println("first(lowest): "+t.first());
        System.out.println("last(highest): "+t.last());
        t.add(23);
        System.out.println("tree set after adding 23 :"+t);
        System.out.println("pollfirst deletes element at 1st "+t.pollFirst());
        System.out.println("poll last deletes last elemet    :"+t.pollLast());
        System.out.println(t);
        t.add(29);
        t.add(303);
        t.add(100);
        t.add(3);
        //way 1
        System.out.println("New treeset :"+t);
        System.out.println("printing using iterator ");
        Iterator itr=t.iterator();
        while (itr.hasNext()){
            System.out.println(itr.next());
        }
        System.out.println("printing using for each ");
        for(int i : t){
            System.out.println(i);
        }

        System.out.println("headset(less than specified element) 20:"+t.headSet(20));
        System.out.println("tailset(greater than equal to specified element) 20:"+t.tailSet(20));
        System.out.println("subset ecluding last"+t.subSet(10,100));

        // extras
        System.out.println("shallow copy :"+t.clone());
        System.out.println("contains(obj) 121 :"+t.contains(121));
        System.out.println("printrind in descending order ");
        Iterator ditr=t.descendingIterator();
        while (ditr.hasNext()){
            System.out.println(ditr.next());
        }
        //higher lower ceilinf floor
        System.out.println("is empty "+t.isEmpty());
        System.out.println("size :"+t.size());
        System.out.println("remove(o)Removes the element from this set if it is present. 303"+t.remove(303));
        System.out.println(t);
        t.clear();
        System.out.println(t);

    }

}
