
//StringBuffer is muttable synchronised thread safe
//StringBuilder is immutable and non Synchronised
public class Stringbuffer {
    public static void main(String args[]){
    StringBuffer name=new StringBuffer("Gayatri");
    System.out.println(name);
    System.out.println(name.append("Gomewadikar"));
    System.out.println(name);//appended string is set to name
    System.out.println(name.insert(7,"Anant"));//counts from 0
    //replace(beginIndex,endIndex-1,string)
        System.out.println(name.replace(7,23," lives in Himalaya"));
    System.out.println(name.reverse());
    System.out.println(name.length());
    StringBuffer s1=new StringBuffer();
    System.out.println(s1.length());
    System.out.println(s1.capacity());////default is
    s1.append("my name is Gayatri .");
    System.out.println(s1.length());
    System.out.println(s1.capacity());

    s1.delete(3,9);
    System.out.println(s1);//from n to excluding 9
    }
}




