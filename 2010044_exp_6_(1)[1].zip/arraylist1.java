
import java.util.*;
public class arraylist1 {
    public static void main(String args[]){
        ArrayList<Integer> array=new ArrayList<>();
       /* System.out.println("enter number: ");
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        System.out.println("Enter numbers "+n);
        for (int i=0;i<n;i++){
            int num=sc.nextInt();
            if(!array.contains(num)){
                array.add(num);
            }
        }
        System.out.println("using ArrayList obj");
        System.out.println(array);
        System.out.println("using for loop");
        for(int j:array){
            System.out.println(j);
        }
        System.out.println("using for loop size function ");
        for(int k=0;k<array.size();k++){
            System.out.println(array.get(k));
        }
        System.out.println("using iterator");
        Iterator itr=array.iterator();
        while(itr.hasNext()){
            System.out.println(itr.next());
        }

*/
        array.add(10);//0
        array.add(20);//1
        array.add(30);
        array.add(40);
        array.add(50);
        array.add(60);
        array.add(-700);
        array.add(2,900);//2
        array.add(1,9900);
        System.out.println("after adding :"+array);
        System.out.println("Size :"+array.size());
        System.out.println("element is present or not "+array.contains(-700));
        System.out.println("element at 0 th position :"+array.get(0));
        System.out.println("isEmpty:"+array.isEmpty());
        System.out.println("setting 4 th element to 500:"+array.set(4,500));
        System.out.println("after setting :"+array);
        System.out.println("indexOf 10 is :"+array.indexOf(10));
        System.out.println("removed element:"+array.remove(4));
        System.out.println("after removing 4 th element"+array);
        System.out.println("after sublist  1 t0 4 from toexcluding:"+array.subList(1,4));
        System.out.println("lastIndexOf :"+array.lastIndexOf(98900));//if that element is not present return -1
        System.out.println("cloned   :"+array.clone());
        System.out.println("original :"+array);
        Iterator itr1=array.iterator();
        while (itr1.hasNext()){
            System.out.println(" "+itr1.next()+" ");
            if(itr1.next().equals(-700)){
                itr1.remove();
            }

        }
        System.out.println("Final Arraylist after removing -700 "+array);
        Collections.sort(array);
        System.out.println("after sorting:"+array);


    }

}