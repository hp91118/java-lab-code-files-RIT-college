//string objects are immutable

public class StringClass {

    public static void main(String args[]){
        String name="Gayatri";
        String surname=new String(" Gomewadikar");
        System.out.println("name string : "+name);
        System.out.println(name.concat(surname));
        String concated=name.concat(surname);
        System.out.println(concated);
        System.out.println(concated.charAt(0)); //starts with 0
        System.out.println(concated.indexOf('G'));//2 nd position
        System.out.println(concated.lastIndexOf("G"));// 8th position
        System.out.println(name.length());//7 as starts with 1
        System.out.println(concated.substring(0,4));//4 th place is excluded
        System.out.println(concated.substring(3));//start witha a
        String fullname="Gayatri gomewadikar";
        System.out.println(concated.equals(fullname));//false
        System.out.println(concated.equalsIgnoreCase(fullname));//true
        System.out.println(concated.compareTo(name));//returns positive if arg is less than string
        System.out.println(name.compareTo(concated));
        System.out.println(concated.compareToIgnoreCase(fullname));
        System.out.println(concated.toUpperCase());//simil. toLowerCase
        System.out.println(concated.contains("aya"));
        System.out.println(concated.isEmpty());
        // equals() compares the content
        System.out.println("Compairing with equals() and ==");
        String s1="Hey";
        String s2="Hey";
        String s3=new String("Hey");
        System.out.println(s1.equals(s2));//t
        System.out.println(s1.equals(s3));//t
        System.out.println(s1==s2);//t
        System.out.println(s1==s3);//f





    }
}
