
import java.util.*;
public class stack1 {
    public static void main(String args[]){
        Stack s=new Stack();
        s.add("sangli"); //0
        s.add("satara");//1
        s.add(12);//3
        s.add(16);//4 top
        System.out.println(s);
        s.add(2,"pune");// 2
        // printing way1
        System.out.println(s);
        //way2
        Iterator itr=s.iterator();
        while (itr.hasNext()){
            System.out.println(itr.next());
        }
        s.pop(); // last in first out so 16 will be deleted
        System.out.println("after pop");
        for(int i=0;i<s.size();i++){
            System.out.println(s.get(i));
        }
        /*
        after pop
        sangli 0
        satara 1
        pune2
        12 3 peek
         */
        System.out.println("size :"+s.size());
        System.out.println("empty boolean :"+s.empty());
        System.out.println("peek :"+s.peek());// top element 12
        System.out.println("searching satar"+s.search("satara"));
        // 12 is at top ---->considered as 1



    }

}
